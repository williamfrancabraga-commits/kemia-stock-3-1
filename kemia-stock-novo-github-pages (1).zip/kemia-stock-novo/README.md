# Kemia Stock — Gestão de Estoque

Sistema web estático para apoiar o projeto de aumento da produtividade no setor de estoque da Kemia.

## Funcionalidades
- Dashboard com indicadores e gráfico por categoria.
- Cadastro, edição, exclusão e pesquisa de materiais.
- Controle de entradas, saídas e ajustes.
- Endereçamento por contêiner, fábrica e almoxarifado.
- Requisições com atendimento e baixa automática.
- Registro de devoluções.
- Relatórios e exportação CSV.
- Backup e restauração em JSON.
- Interface responsiva para computador e celular.

## Como executar
Abra `index.html` no navegador. Para publicação, envie os três arquivos (`index.html`, `styles.css`, `app.js`) e este README para a raiz de um repositório GitHub.

## Publicar no GitHub Pages
1. Crie um repositório no GitHub, por exemplo `kemia-stock`.
2. Envie os arquivos para a raiz do repositório.
3. Acesse **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`.
6. Salve e aguarde a publicação.
7. O endereço ficará no formato `https://SEU-USUARIO.github.io/kemia-stock/`.

## Atenção sobre os dados
Esta versão usa `localStorage`: os dados ficam salvos somente no navegador e dispositivo utilizados. O GitHub Pages hospeda arquivos estáticos e não oferece banco de dados nem sincronização entre usuários. Use **Backup dos dados** para baixar uma cópia JSON regularmente. Para uso simultâneo por vários operadores, será necessário integrar um backend e autenticação.

## Dados iniciais
O sistema vem com materiais de demonstração e os indicadores de referência apresentados no projeto. Revise os saldos e endereços com a contagem física antes de utilizar operacionalmente. As metas são projeções, não resultados comprovados.
